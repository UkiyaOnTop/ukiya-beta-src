const db = require('quick.db')
const Discord = require('discord.js');

module.exports = {
config: {
    name : 'afk',
    usage: "afk"
},

    run : async(client, message, args) => {
        const content = args.join(" ") ? args.join(' ') : "AFK"
        await db.set(`afk-${message.author.id}+${message.guild.id}`, content)
        
        const afkEmbed = new Discord.MessageEmbed()
        .setColor("#222222")
        .setTitle(`${message.author} is now afk with the status:`)
        .setDescription(`> **${content}**`)
        message.channel.send(afkEmbed)                
    }
}