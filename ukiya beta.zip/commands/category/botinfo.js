const db = require("old-wio.db");
const Discord = require ("discord.js")
const { version } = require('../../package.json');
const ms = require('pretty-ms');
const { version: discordjsVersion } = require('discord.js');
module.exports = {
config: {
  name: "botinfo",
  category: "category",
  aliases: ['binfo', 'botstats'],
  description: 'Check\'s bot\'s status',
},
  run: async (bot, message, args) => {
   message.delete();
      message.channel.send(new Discord.MessageEmbed()
            .setColor('#212226')
            .setDescription(`<:3_:907092790461231145> __**Owner**__ : \nKnocker#0004 \nfelony#6666`)
            .addField('<:5_:907053261603876915> **Uptime** :', `${ms(bot.uptime)}`, true)
            .addField('<:5_:907053261603876915> **Guild Count** :', `${bot.guilds.cache.size} guilds`, true)
            .addField(`<:5_:907053261603876915> **User Count** :`, `${bot.guilds.cache.reduce((users , value) => users + value.memberCount, 0)} users`, true)
            .addField('<:5_:907053261603876915> **Commands** :', `${bot.commands.size} cmds`,true)
        );
    }
}
