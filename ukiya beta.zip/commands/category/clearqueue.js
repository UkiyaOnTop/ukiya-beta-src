module.exports = {
    config: {
        name: 'clearqueue',
        aliases: ['clearq', 'clear'],
        description: 'Skip all songs in queue',
        accessableby: "everyone"
    },
run: async (bot, message, args, ops) => {
        const { channel } = message.member.voice;
        if (!channel) return message.channel.send('I\'m sorry but you need to be in a voice channel to skip music!');
        if (message.guild.me.voice.channel !== message.member.voice.channel) {
            return message.channel.send("👎");
          }
        const serverQueue = ops.queue.get(message.guild.id);
        if (!serverQueue) return message.channel.send('👎');
        if (!serverQueue.songs) return message.channel.send('👎');
      try {
        serverQueue.songs = [];
        serverQueue.connection.dispatcher.end();
        return message.channel.send("👍");
      } catch {
          serverQueue.connection.dispatcher.end();
          await channel.leave();
          return message.channel.send("👎");
      }
    }
};