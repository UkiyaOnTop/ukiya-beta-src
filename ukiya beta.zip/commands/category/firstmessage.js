const { Client, Message, MessageEmbed } = require("discord.js");

module.exports = {
config: {
  name: "firstmessage",
  aliases: ["firstmsg"],
description: "Returns first message of that channel"
},
  /**
   * @param {Client} client
   * @param {Message} message
   * @param {String[]} args
   */
  run: async (client, message, args) => {
    
    const fetchMessages = await message.channel.messages.fetch({
      after: 1,
      limit: 1,
    });
    const msg = fetchMessages.first();

    message.channel.send(
      new MessageEmbed()
        .setTitle(`__First Messsage In ${message.guild.name}__`)
        .setURL(msg.url)
        .setDescription("content: " + msg.content)
        .addField("author", msg.author, true)
    );
  },
};