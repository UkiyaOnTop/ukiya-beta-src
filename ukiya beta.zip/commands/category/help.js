const Discord = require("discord.js");

module.exports = {
config: {
  name: "help"
},
  run: async (client, message, args) => {
    
   

    const Embed = new Discord.MessageEmbed()
      .setColor("#222222")
      .setTitle('**Help**')
      .setDescription("<:1_:912060912674947072> an askerisk(*) means the command has subcommands")
      .addField(
        "**configuration**",
        "`prefix`, `setbanner`, `seticon`, `welcome*`, `autorole*`, `backup`, `antilink`, `statusrole`"
      )
      .addField(
        "**mod**",
        "`Ban`, `Kick`, `lock`, `unlock`, `Unban`, `Purge`, `role`, `slowmode`, `rolecreate`, `addemoji`, `setnick`, `addthese`, `usersbanned`, `nuke`, `purgeuser`, `botclear`"
      )
      .addField(
        "**utility**",
        "`membercount`, `avatar`, `banner`, `serverbanner`, `servericon`, `embed`, `serverinfo`, `whois`, `roles`, `color`, `emojilist`, `poll`, `firstmessage`, `allbots`"
      )
            .addField(
        "**misc**",
        "`help`, `invite`, `enlarge`, `uptime`, `emojiid`, `userid`, `inrole`, `ping`, `botinfo`, `linkshorten`, `define`, `instagram`, `vote`, `afk`, `credits`, `snipe`, `record`, `playrecording`, `imdb`, `screenshot`"
      );
    return message.channel.send(Embed);
  }
}; 