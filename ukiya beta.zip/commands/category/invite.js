const Discord = require("discord.js");

module.exports = {
config: {
    name: "invite",
    description: "Get the bot's",
    aliases: ["inv"]
},
    run: async (client, message, args) => {

        let embed = new Discord.MessageEmbed()
        .setColor("#303135")
            .setDescription("> [**Invite Me**](https://discord.com/api/oauth2/authorize?client_id=894133385340014675&permissions=138983894135&scope=bot)")
        message.channel.send(embed);
    }
}
