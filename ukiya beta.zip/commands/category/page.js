const { MessagePagination } = require("spud.js")
const { MessageEmbed } = require("discord.js")
const embed1 = new MessageEmbed().setTitle('test')
const embed2 = new MessageEmbed().setTitle('test')
const embed3 = new MessageEmbed().setTitle('test')
const embed4 = new MessageEmbed().setTitle('test')
//advanced embeds can be used its upto you

module.exports = {
  config: {
    name: "pagination",
    description: "makes a cool pagination"
  },
  run: async (client, message, args) => {

    const pagination = new MessagePagination({
      message,// use message:message,
      embeds: [embed1, embed2, embed3, embed4],//array of embeds
      button: [
        {
          name: 'previous', // The button name you wish to modify
          emoji: '<:icons_leftarrow:934736826953007104>',
          style: 'SECONDARY', // Must be a valid discord button style
        },
        {
          name: 'pageTravel', // The button name you wish to modify
          emoji: '<:skipto:934740122379911189>',
          style: 'SECONDARY', // Must be a valid discord button style
        },
        {
          name: 'next', // The button name you wish to modify
          emoji: '<:icons_rightarrow:934738058459357194>',
          style: 'SECONDARY', // Must be a valid discord button style
        },
      ],
      replyOptions: {
        mention: true,//pings author , set to false to not ping
        message, //the message object
      },
      fastSkip: false, //skip to last page and first page
      resetTimerOnClick: false,// if this is set to true then it will get disabled only if the buttons are not used until time runs out
      pageTravel: true,
      max: 10, //max no of clicks before disabling (if not clicked max time then disabled based on time)
      time: 60000,//time till disable (60000 = 60 seconds)
    });

  }
}