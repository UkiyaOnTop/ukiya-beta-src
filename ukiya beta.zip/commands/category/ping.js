const Discord = require("discord.js");

module.exports = {
    config: {
        name: "ping",
        description: "Shows ping of the bot",
        category: 'utility',
        usage: "ping",
        example: "ping"
    },
    run: async (bot, message, args) => {
        let start = Date.now();
  
  message.channel.send({embed: {description: "🔍 I think my ping is high...", color: "#212226"}}).then(m => {
    
    let end = Date.now();
    
    let embed = new Discord.MessageEmbed()
    .addField("<a:bats:896155949566410792>",  Math.round(bot.ws.ping) + "ms", true)
    .setColor("#212226");
    m.edit(embed).catch(e => message.channel.send(e));
    
  });
    }
};