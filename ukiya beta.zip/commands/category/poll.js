const Discord = require('discord.js');
const { warn } = require('../../emojis.json')

module.exports = {
config: {  
  name: "poll",
  aliases: ["createpoll"]
},

run: async(client, message, args) => {
    let user = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;

    if (!message.member.hasPermission("MANAGE_MESSAGES")) return message.channel.send({ embed: { color: "fe6464", description: `${warn} ${message.author}: You're **missing** permission: \`manage_messages\``}});
    if (!message.guild.me.hasPermission("EMBED_LINKS")) return message.channel.send({ embed: { color: "fe6464", description: `${warn} ${message.author}: I'm **missing** permission: \`embed_links\``}});

  const pollEmbed = new Discord.MessageEmbed()
  .setDescription(`${warn} ${message.author} Plese provide a poll question`)
  .setColor("#212226")
if(!args[0]) return message.channel.send(pollEmbed);
  let msg = args.slice(0).join(' ');

  let embed = new Discord.MessageEmbed()
    .setTitle(`__poll__`)
    .setColor("#212226")
    .setDescription(`**${msg}**`);
      
  message.delete();

  message.channel.send(embed).then(messageReaction => {
    messageReaction.react('👍');
    messageReaction.react('👎');
  });
}
}