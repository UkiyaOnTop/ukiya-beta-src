const { MessageEmbed } = require('discord.js')
const Discord = require('discord.js')
const db = require('quick.db')
module.exports = {
config: {
    name: 'screenshot',
    aliases: ['ss'],
    description: 'Screenshot a website'
},
    run : async (client, message, args) => {
      let content = args[0]
      if(!content) {
        return message.channel.send({ embed: { color: "#222222", description: "Please provide a website url" } })
      }
      if(content.toLowerCase().startsWith(`https://`)||content.toLowerCase().startsWith(`http://`)) {
    let imgae = `https://api.popcatdev.repl.co/screenshot?url=${args[0]}`
let image = new Discord.MessageAttachment(imgae, "ss.png")
let embed = new MessageEmbed().setImage('attachment://ss.png')
.setTitle(`Screenshot from ${content}`)
message.channel.send({ embeds: [embed], files: [image] })
      }else {
        message.channel.send(`That is not a link!`)
      }
    }
}