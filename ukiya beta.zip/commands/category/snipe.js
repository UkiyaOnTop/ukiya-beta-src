const Discord = require("discord.js")
const config = require("../../config")
const db = require("quick.db")
module.exports = {
config: {
  name: "snipe",
  aliases: ["s"]
},

  run: async (client, message, args) => {
    let mentionedMember = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!mentionedMember) mentionedMember = message.member;

    let prefix = await db.fetch(`prefix_${message.guild.id}`)
    if (prefix == null) {
      prefix = config.PREFIX
    }

    const msg = client.snipes.get(message.channel.id)
    if (!msg) return message.channel.send({ embed: { color: "#222222", description: `${message.author}:  there is nothing to snipe` } })
    if (message.author.bot) return;
    const embed = new Discord.MessageEmbed()
      .setAuthor(msg.author, message.guild.members.cache.find(u => u.user.tag == msg.author).user.displayAvatarURL({ format: "png", dynamic: true }))
      .setDescription(msg.content)
      .setColor("#222222")
    if (msg.image) embed.setImage(msg.image)

    message.channel.send(embed)


  }
}