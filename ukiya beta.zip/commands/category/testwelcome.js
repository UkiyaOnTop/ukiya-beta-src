module.exports = {
config: {
    name: "testwelcome",
    aliases: ["testwelc"],
    description: "testwelcome members",
    usage: "!testwelcome"
},
    run: async(client, message, args) => {
        if (!message.member.hasPermission("ADMINISTRATOR")) return message.channel.send('You do not have admin permission');
        if (message.deletable) message.delete()
        client.emit('guildMemberAdd', message.member);
    }
}