const Discord = module.require("discord.js");

module.exports = {
config: {
    name:"userid"
},
    run: async (client, message, args) => {
    var mention = message.guild.member(message.mentions.users.first());
    if(!mention) return message.channel.send("Please mention a user")
    const lolicon = mention.user.avatarURL;
    const lolid = new Discord.MessageEmbed()
    .setColor("#222222")
    .setTitle(`${mention.user.username}\'s user id`)
    .setDescription(`${mention.id}`)
    message.channel.send(lolid)  
}
}
