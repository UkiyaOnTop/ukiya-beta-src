const Discord = require("discord.js");

module.exports = {
config: {
  name: "variables"
},
  run: async (client, message, args) => {
    
   

    const Embed = new Discord.MessageEmbed()
    .setTitle(`__**welcome variables**__`)
    .setDescription("__{user.mention}__ - mentions the new member\n__{user.name}__ - displays the new members tag\n__{server}__ - diplays the server name\n__{membercount}__ displays the amount of members in the server")
    .setColor("#222222");
    return message.channel.send(Embed);
  }
}; 