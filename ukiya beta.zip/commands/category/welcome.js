const Discord = require("discord.js");

module.exports = {
config: { 
  name: "welcome"
},
  run: async (client, message, args) => {
    
   

    const Embed = new Discord.MessageEmbed()
    .setDescription("__**welcome help**__\nwelcomemessage \ntestwelcome \nwelcomechannel \nleavechannel \nleavemessage \nvariables")
    .setColor("#222222");
    return message.channel.send(Embed);
  }
}; 