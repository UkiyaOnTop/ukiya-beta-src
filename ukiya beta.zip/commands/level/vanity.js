const { MessageEmbed } = require("discord.js");
const presenceData = require("../../database/guildData/pres");
require('discord-reply');
const { warn } = require('../../emojis.json')



module.exports = {
config: {
    name: 'vanity',
    aliases: ["spm", "statusrole", "presencerole"],
    description: 'Set the message that the user wants to set to get a role!'
},
    /** 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */

    run: async (client, message, args) => {

        if (!message.member.permissions.has("ADMINISTRATOR")) return message.lineReply({ embed: { color: "222222", description: `${warn} ${message.author} To set the status role you require admin perms` } });

        const choices = ["set", "delete", "open"];
        const choice = args[0];
        if (!choices.includes(choice)) return message.lineReply('Invalid Option!');

        switch (choice) {
            case ('set'): {
                let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[0]);
                if (!role) return message.lineReply({ embed: { color: "222222", description: `${warn} ${message.author} Please provide a link to shorten` } });

                let cont = args.slice(2).join(" ");
                if (!cont) return message.lineReply('Please provide the content for the verfication message!');
                if (cont.lenght > 20) return message.lineReply('The content provided can not be above 20 characters!');

                presenceData.findOne({
                    guild: message.guild.id
                }, async (err, data) => {
                    if (!data) {
                        data = new presenceData({
                            guild: message.guild.id,
                            content: {
                                descrip: cont,
                                role: role.id,
                            }
                        }).save();

                        return message.channel.send('The presence message was set');
                    } else {
                        await presenceData.findOneAndDelete({
                            guild: message.guild.id
                        });
                        data = new presenceData({
                            guild: message.guild.id,
                            content: {
                                descrip: cont,
                                role: role.id,
                            }
                        }).save()
                        return message.channel.send('The presence message was updated');
                    }
                })
                break;
            }

            case ('delete'): {
                await presenceData.findOneAndDelete({
                    guild: message.guild.id
                });
                message.channel.send('The presence message has been deleted');
                break;
            }

            case ('open'): {
                await presenceData.findOne({
                    guild: message.guild.id
                }, async (err, data) => {
                    if (!data) return message.lineReply('There is no presence message set');

                    await message.channel.send(new MessageEmbed()
                        .setTitle('Current Presence autorole')
                        .setDescription(`Change your status to: **${data.content.descrip.toLowerCase()}** to get role`).setColor("#222222")
                    )
                })
                break;
            }
        }
    }
}