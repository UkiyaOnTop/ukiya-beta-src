const { MessageEmbed } = require('discord.js');
const Discord = require('discord.js');
const db = require('quick.db')
const { ownerID } = require("../../owner.json")
const { warn } = require('../../emojis.json')

module.exports = {
    config: {
        name: "ban",
        aliases: ["b", "banish"],
        description: "Bans the user",
        usage: "[name | nickname | mention | ID] <reason> (optional)",
    },
    run: async (bot, message, args) => {
        let banPermErr = new Discord.MessageEmbed()
        .setDescription(`${warn} ${message.author} You Dont Have The Permissions To Ban Users`)
        
        if(!message.channel.permissionsFor(message.member).has("BAN_MEMBERS") ) return message.channel.send(banPermErr);
       
       const e1 =  new MessageEmbed()

       .setDescription(`${warn} ${message.author} You Dont Have The Permissions To Ban Users`)
      .setColor("#212226")

        const e2 =  new MessageEmbed()

       .setDescription(`${warn} ${message.author} Please Provide A User To Ban`)
      
       .setColor("#212226")

       const e3 =  new MessageEmbed()

       .setDescription(`${warn} ${message.author} User Is Not In The Guild`)
      
       .setColor("#212226")

       const e4 =  new MessageEmbed()

       .setDescription(`${warn} ${message.author} You Cannot Ban Yourself`)
      
       .setColor("#212226")

       const e5 =  new MessageEmbed()

       .setDescription(`${warn} ${message.author} Cant Ban That User`)
      
       .setColor("#212226")
       
        try {
            if (!message.member.hasPermission("BAN_MEMBERS") && !ownerID .includes(message.author.id)) 
            
            return message.channel.send("");
            if (!message.guild.me.hasPermission("BAN_MEMBERS")) return message.channel.send(e1);
            if (!args[0]) return message.channel.send(e2)

            let banMember = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.guild.members.cache.find(r => r.user.username.toLowerCase() === args[0].toLocaleLowerCase()) || message.guild.members.cache.find(ro => ro.displayName.toLowerCase() === args[0].toLocaleLowerCase());
            if (!banMember) return message.channel.send(e3);
            if (banMember === message.member) return message.channel.send(e4)

            var reason = args.slice(1).join(" ");

            if (!banMember.bannable) return message.channel.send(e5)
            try {
            message.guild.members.ban(banMember)
            banMember.send(`**You Have Been Banned From ${message.guild.name} for - ${reason || "No Reason"}**`).catch(() => null)
            } catch {
                message.guild.members.ban(banMember)
            }
            if (reason) {
            var sembed = new MessageEmbed()
                .setColor("#212226")
                .setDescription(`**${banMember.user.username}** has been banned for ${reason}`)
            message.channel.send(sembed)
            } else {
                var sembed2 = new MessageEmbed()
                .setColor("#212226")
                .setDescription(`**${banMember.user.username}** has been banned`)
            message.channel.send(sembed2)
            }
            let channel = db.fetch(`modlog_${message.guild.id}`)
            if (channel == null) return;

            if (!channel) return;

            const embed = new MessageEmbed()
                .setAuthor(`${message.guild.name} Modlogs`, message.guild.iconURL())
                .setColor("#212226")
                .setThumbnail(banMember.user.displayAvatarURL({ dynamic: true }))
                .setFooter(message.guild.name, message.guild.iconURL())
                .addField("**Moderation**", "ban")
                .addField("**Banned**", banMember.user.username)
                .addField("**ID**", `${banMember.id}`)
                .addField("**Banned By**", message.author.username)
                .addField("**Reason**", `${reason || "**No Reason**"}`)
                .addField("**Date**", message.createdAt.toLocaleString())
                .setTimestamp();

            var sChannel = message.guild.channels.cache.get(channel)
            if (!sChannel) return;
            sChannel.send(embed)
        } catch (e) {
            return message.channel.send(`**${e.message}**`)
        }
    }
};
