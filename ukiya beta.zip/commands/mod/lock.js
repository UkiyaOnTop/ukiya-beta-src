const Discord = require('discord.js');
const { Console } = require('console');

module.exports = {
    config: {
        name: "lock",
        description: "lock channel",
        aliases: []
    },
    run: async (bot, message, args) => {
        let lockPermErr = new Discord.MessageEmbed()
        .setDescription("you don't have permissions to use this")
        
        if(!message.channel.permissionsFor(message.member).has("MANAGE_MESSAGES") ) return message.channel.send(lockPermErr);

        let channel = message.channel;

        try {
          channel.updateOverwrite(message.guild.id, { SEND_MESSAGES: false });
        } catch (e) {
            console.log(e);
        }

        message.channel.send({ embed: { color: "#222222", description: `<:lock:908397279583559760> channel locked` } });
    }
}