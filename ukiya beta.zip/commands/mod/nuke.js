const Discord = require('discord.js');
const { approve } = require('../../emojis.json')
module.exports = {
config: {
  name: 'nuke',
  permissions: [ 'MANAGE_MESSAGES', 'MANAGE_CHANNELS' ],
  clientPermissions: [ 'MANAGE_CHANNELS' ]
},

  run: async (client, message) => {
        let nukePermErr = new Discord.MessageEmbed()
        .setDescription(`${approve} ${message.author} You Do Not Have Permissions To Nuke Channels`)
        
        if(!message.channel.permissionsFor(message.member).has("MANAGE_CHANNELS") ) return message.channel.send(nukePermErr);

    await message.channel.send({ embed: { color: "#303135", description: `${message.author}This will remove all msgs in this channel. Continue?` } });

    const filter = _message => message.author.id === _message.author.id && ['y','n','yes','no'].includes(_message.content.toLowerCase());
    const options = { max: 1, time: 30000, errors: ['time'] };
    const proceed = await message.channel.awaitMessages(filter, options)
    .then(collected => ['y','yes'].includes(collected.first().content.toLowerCase()) ? true : false)
    .catch(() => false);

    if (!proceed){
      return message.channel.send({ embed: { color: "#212226", description: `${approve} ${message.author} You cancelled the nuke command.` } });
    };

    return message.channel.send({ embed: { color: "#212226", description: `${approve} The nuke has been deployed, nuking **#${message.channel.name}** in 10 seconds` } })
    .then(() => setTimeout(() => message.channel.clone()
    .then(() => message.channel.delete().catch(() => null)), 10000))
  }
};
