const Discord = require('discord.js');
const { Console } = require('console');

module.exports = {
    config: {
        name: "unlock",
        description: "unlock channel",
        aliases: []
    },
    run: async (bot, message, args) => {
        let lockPermErr = new Discord.MessageEmbed()
        .setTitle("**User Permission Error!**")
        .setDescription("**Sorry, you don't have permissions to use this! ❌**")
        
        if(!message.channel.permissionsFor(message.member).has("MANAGE_MESSAGES") ) return message.channel.send(lockPermErr);

        let channel = message.channel;

        try {
          channel.updateOverwrite(message.guild.id, { SEND_MESSAGES: true });
        } catch (e) {
            console.log(e);
        }

        message.channel.send({ embed: { color: "#222222", description: `<:unlock:908396517000364104> channel unlocked` } });
    }
}