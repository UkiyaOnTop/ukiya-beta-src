module.exports = {
  config: {
    name: "reload",
    aliases: ["restart", "refresh"],
    category: "owner",
    description: "restart bot",
    usage: "",
    accessableby: "Owner"
  },
  run: async (bot, message, args) => {
    if (message.author.id === "612279232290095114") {
      const Discord = require("discord.js");
      const embed = new Discord.MessageEmbed()
        .setColor("#303135")
        .setTitle("Restarting...");
      console.log(`${bot.user.username} is restarting...`);
      message.channel.send(embed).then(sentMessage => process.exit(0));
    }
  }
};