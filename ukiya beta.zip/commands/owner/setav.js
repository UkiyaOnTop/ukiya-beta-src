const Discord = require('discord.js');
const client = new Discord.Client()

module.exports = {
config: {
    name: "setavatarbot",
    aliases: ["setbav"]
},
    run: async (client, message, args) => {
   let avatarurl = args.join(" ");
   if(message.author.id !== "612279232290095114") return message.channel.send('Insufficient permission!!')
   client.user.setAvatar(`${avatarurl}`)
   if (!avatarurl) return message.channel.send(`Usage: setavatarbot <url>`)
   let embed = new Discord.MessageEmbed()
       .setTitle('New Avatar Set')
       .setImage(`${avatarurl}`)
    message.channel.send(embed)
    .catch(e => {
        console.log(e)
        return message.channel.send("Something Went Wrong!")
    })
  }
}