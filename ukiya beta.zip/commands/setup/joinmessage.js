const Discord = module.require("discord.js")
const joinModel = require("../../database/guildData/joinmsg");
const { warn } = require('../../emojis.json')


module.exports = {
config: {
  name: "joinmessage",
  description: "Change the welcome message per server!",
  aliases: ["joinmsg", "welcomemsg", "jmsg", "welcomemessage", "wlcmessage", "welcmsg", "welcmessage"]
},
  run: async (client, message, args) => {
    if (!message.member.hasPermission("MANAGE_CHANNELS")) {
      return message.channel.send("You dont have enough Permissions!")
    }
    const text = args.join(" ");
    if (!args[0]) {
      return message.channel.send({ embed: { color: "222222", description: `${warn} ${message.author} To Set The Welcome Message Use **welcomemessage <text>**` } })
    }
    if (text !== "off") {
      const data = await joinModel.findOne({
        GuildID: message.guild.id
      });

      if (data) {
        await joinModel.findOneAndRemove({
          GuildID: message.guild.id
        });
        let newData = new joinModel({
          JoinMsg: args.join(" "),
          GuildID: message.guild.id
        });
        newData.save();
        message.channel.send(`Join Message set to ${newData.JoinMsg}`);

      } else if (!data) {

        let newData = new joinModel({
          JoinMsg: args.join(" "),
          GuildID: message.guild.id
        });
        newData.save();
        message.channel.send(`Join Message set to ${newData.JoinMsg}`);

      }
    } else if (text === "off") {
      const data2 = await joinModel.findOne({
        GuildID: message.guild.id
      });

      if (data2) {
        await joinModel.findOneAndRemove({
          GuildID: message.guild.id
        });

        return message.channel.send(`Join Message has been turned off!`);

      } else if (!data2) {
        return message.channel.send(`Join Message isn't setup!`)
      }
    }
  }
}
