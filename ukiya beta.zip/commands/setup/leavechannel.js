const Discord = module.require("discord.js")
const joinModel = require("../../database/guildData/leavechannel");
const { warn } = require('../../emojis.json')


module.exports = {
config: {
  name: "leavechannel",
  description: "Change the goodbye channel per server!",
  aliases: ["gchannel", "goodbyechannel"]
},
  run: async (client, message, args) => {
    if (!message.member.hasPermission("MANAGE_CHANNELS")) {
      return message.channel.send({ embed: { color: "222222", description: `${warn} ${message.author} you dont have perms` } })
    }
    if (!message.guild.me.hasPermission("MANAGE_CHANNELS")) {
      return message.channel.send({ embed: { color: "222222", description: `${warn} ${message.author} i dont have perms to set this up` } })
    }
    if (!args[0]) {
      return message.channel.send({ embed: { color: "222222", description: `${warn} ${message.author} To Set The Leave Channel Use **leavechannel <#channel>**` } })
    }
    if (message.mentions.channels.first()) {
    const data = await joinModel.findOne({
      GuildID: message.guild.id
    });

    if (data) {
      await joinModel.findOneAndRemove({
        GuildID: message.guild.id
      });

      message.channel.send(`Goodbye Channel set to ${message.mentions.channels.first()}`);

      let newData = new joinModel({
        Bye: message.mentions.channels.first().id,
        GuildID: message.guild.id
      });
      newData.save();
    } else if (!data) {
      message.channel.send(`Goodbye Channel set to ${message.mentions.channels.first()}`);

      let newData = new joinModel({
        Bye: message.mentions.channels.first().id,
        GuildID: message.guild.id
      });
      newData.save();
    }
  } else if (args[0] === "off") {
      const data2 = await joinModel.findOne({
        GuildID: message.guild.id
      });

      if (data2) {
        await joinModel.findOneAndRemove({
          GuildID: message.guild.id
        });

        return message.channel.send(`Goodbye channel has been turned off!`);

      } else if (!data2) {
        return message.channel.send(`Goodbye channel isn't setup!`)
      }
    }
  }
}
