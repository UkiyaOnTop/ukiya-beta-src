const Discord = require('discord.js')
const { parse } = require("twemoji-parser");
const { MessageEmbed } = require("discord.js");
const { warn } = require('../../emojis.json')
module.exports = {
config: {  
    name: "addthese",
    category: "moderation",
    aliases: ["multiadd", "multisteal"]
},
    run: async (client, message, args) => {
        if (!message.member.hasPermission("MANAGE_EMOJIS")) {
return message.channel.send(`**You Don't Have Permission To Use This Command**`)
}
        const emojis = args.join(" ").match(/<?(a)?:?(\w{2,32}):(\d{17,19})>?/gi)
        if (!emojis) return message.channel.send({ embed: { color: "212226", description: `${warn} ${message.author}: Please provide emojis to add` } });
        emojis.forEach(emote => {
        let emoji = Discord.Util.parseEmoji(emote);
        if (emoji.id) {
      const Link = `https://cdn.discordapp.com/emojis/${emoji.id}.${
       emoji.animated ? "gif" : "png"
}`
            message.guild.emojis.create(
                `${Link}`,
                `${`${emoji.name}`}`
            ).then(em => message.channel.send({ embed: { color: "#212226", description: em.toString() + " added." } })).catch(error => {
              message.channel.send("something went wrong my boi try again")
                console.log(error)
})
          
        }
        })
}
}