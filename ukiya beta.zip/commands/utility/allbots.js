const { MessageEmbed } = require('discord.js');

module.exports = {
config: {
    name: 'allbots',
    description: 'show all bots in guild',
    usage: 'allbots'
    },
    run: async (client, message, args) => {
    
    let checked = '<:on:908397171466973195>';
    let unchecked = '<:off:908397107235405825>';


    const allbots = message.guild.members.cache.filter(m => m.user.bot).map((m) => m).map((m) => `${m.user.flags ? checked : unchecked} ${m.user.tag} (${m.id})`).join('\n');

    const embed = new MessageEmbed()
    .setColor('#222222')
    .setDescription(allbots);
    message.channel.send(embed)
  }
};