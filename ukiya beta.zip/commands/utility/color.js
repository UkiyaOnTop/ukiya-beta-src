const pop = require("popcat-wrapper")
const { MessageEmbed } = require("discord.js")
const { warn } = require('../../emojis.json')
module.exports ={
config: {
  name: "color",
  aliases: ["hex"]
},

  async run (client, message, args) {
    let color = args[0]
    if(!color) return message.channel.send({ embed: { color: "212226", description: `${warn} ${message.author} Please provide a hex code` } })
    if(color.includes("#")) {
      color = color.split("#")[1]
    }
    try {
    const info = await pop.colorinfo(color)
    
      const embed = new MessageEmbed()
      .addField('Hex', info.hex, true)
      .addField('RGB', info.rgb, true)
      .setColor(info.hex)
      message.channel.send(embed)
    } catch (error) {
      return message.channel.send({ embed: { color: "fe6464", description: `${warn} ${message.author} Invalid color` } })
    }
  }
}