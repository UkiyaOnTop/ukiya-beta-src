const Discord = require("discord.js");

module.exports = {
config: {
  name: "credits"
},
  run: async (client, message, args) => {
    
   

    const Embed = new Discord.MessageEmbed()
    .setTitle("")
    .setDescription(`[__/owners__](https://discord.ly/ukiya) \n\n> felony#6666 \n> Knocker#0004\n\n> [__/swervo__](https://discord.gg/cBD5m35pHC) \n\n> [__/ukiya__](https://discord.gg/7fjt2g7QsV)`)
    .setColor("#303135");
    return message.channel.send(Embed);
  }
}; 