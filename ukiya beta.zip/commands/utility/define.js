const urban = require('relevant-urban');
const { MessageEmbed } = require('discord.js');
const { warn } = require('../../emojis.json')

module.exports = {
config: {
        name: "define",
        aliases: ["ud", "urban"],
        category: "info",
        description: "Give information about urban words!",
        usage: "[word]"
},
        
    
    run: async (bot, message, args) => {
        if(!args[0])
        return message.channel.send({ embed: { color: "212226", description: `${warn} ${message.author} Please enter something to define` } });

        let image = "";
        try {
            let res = await urban(args.join(' '))
                if (!res) return message.channel.send({ embed: { color: "212226", description: `${warn} ${message.author} I couldnt find anything` } });
                let { word, urbanURL, definition, example, thumbsUp, thumbsDown, author } = res;

                let embed = new MessageEmbed()
                    .setColor("#212226")
                    .setDescription(`**Definition**\n*${definition || "No meaning"}*\n\n**Example**\n*${example || "No Example"}*`)
                    .addField('**Rating:**', `**\`👍: ${thumbsUp} | 👎: ${thumbsDown}\`**`)

                message.channel.send(embed)
            
        } catch (e) {
            console.log(e)
            return message.channel.send({ embed: { color: "212226", description: `${warn} ${message.author} Something went wrong try again` } })
        }
    }
}