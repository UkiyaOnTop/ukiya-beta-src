const { MessageEmbed } = require('discord.js');

module.exports = {
config: {
        name: 'emojilist',
        aliases: ['elist'],
        description: 'Shows the List of all the Emojis in the server'
},
    run: async (client, message, args) => {

        let Emojis = "";
        let EmojisAnimated = "";
        let EmojiCount = 0;
        let Animated = 0;
        let OverallEmojis = 0;

        function Emoji(id) {
            return client.emojis.cache.get(id).toString();
        }
        message.guild.emojis.cache.forEach((emoji) => {
            OverallEmojis++;
            if (emoji.animated) {
                Animated++;
                EmojisAnimated += Emoji(emoji.id);
            } else {
                EmojiCount++;
                Emojis += Emoji(emoji.id);
            }
        });
        let Embed = new MessageEmbed()
            .setTitle(`${OverallEmojis} total emojis in ${message.guild.name}`)
            .setDescription(
                `**Animated**:\n${EmojisAnimated}\n\n**Standard**:\n${Emojis}`
            )
            .setColor("#212226");

        if (Embed.length > 6000) {
            return message.channel.send(
                `I'm sorry but, my limit is 6000 characters only!`
            );
        } else {
            message.channel.send(Embed);
        }

    }
}