const Discord = require("discord.js");
const { parse } = require("twemoji-parser");
const { MessageEmbed } = require("discord.js");
const { warn } = require('../../emojis.json')
const Color = `#303135`;

module.exports = {
  config : {
    name: "jumbo",
    aliases: ["en","enlarge"],
    category: "fun",
    description: "Converting Server emoji to PNG/GIF!"},
    run: async(client, message, args) => {


        const authoravatar = message.author.avatarURL();
        const emoji = args[0];
        if (!emoji) return message.channel.send({ embed: { color: "212226", description: `${warn} ${message.author} Please provide a emoji` } });

        let customemoji = Discord.Util.parseEmoji(emoji);

        if (customemoji.id) {
            const Link = `https://cdn.discordapp.com/emojis/${customemoji.id}.${customemoji.animated ? "gif" : "png"
                }`;

            const Added = new MessageEmbed()
                .setAuthor(`Enlarged Emoji`)
                .setColor(`#212226`)
                .setImage(Link
                );
            return message.channel.send(Added);
        } else {
            let CheckEmoji = parse(emoji, { assetType: "png" });
            if (!CheckEmoji[0])
                return message.channel.send({ embed: { color: "212226", description: `${warn} ${message.author} Please provide a emoji` } });
            message.channel.send(
                `You Can Use Normal Emoji Without Adding In Server!`
            );
        }
    }
};