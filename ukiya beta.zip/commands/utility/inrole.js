const Discord = require('discord.js');
const { COLOR } = require("../../config");
const { warn } = require('../../emojis.json')

module.exports = {
config: {
  name: "inrole",
  aliases: ["ir"]
  },

  run: async (client, message, args) => {
    if (args.includes("@everyone")) return;

    if (args.includes("@here")) return;

    const inroleEmbed = new Discord.MessageEmbed()
      .setDescription(`${warn} ${message.author}: please provide a role`)
      .setColor("#212226")
    if (!args[0]) return message.channel.send(inroleEmbed)

    let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[0]) || message.guild.roles.cache.find(r => r.name.toLowerCase() === args.join(' ').toLocaleLowerCase());
    if (!role) return message.channel.send({ embed: { color: "#222222", description: `${message.author}: You need to enter a **valid** role` } });

    let membersWithRole = message.guild.members.cache.filter(member => {
      return member.roles.cache.find(r => r.name === role.name);
    }).map(member => {
      return member.user.tag;
    })
    if (membersWithRole > 2048) return message.channel.send('List is too long')

    let roleListEmbed = new Discord.MessageEmbed()
      .setColor("#212226")
      .setTitle(`Members in '${role.name}'`)
      .setDescription(`**${membersWithRole.join("\n")}**`);
    message.channel.send(roleListEmbed);
  }
}