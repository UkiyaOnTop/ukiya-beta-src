const shorten = require('isgd');
const { warn } = require('../../emojis.json')


module.exports = {
    config : {
      name: "linkshorten",
    aliases: ["shorten", "shortenurl"]
},

    run: async (client, message, args) => {

        if (!args[0]) return message.reply({ embed: { color: "222222", description: `${warn} ${message.author} Please provide a link to shorten` } })

        if (!args[0]) {
            shorten.shorten(args[0], function(res) {
                if(res.startsWith('Error:')) return message.reply({ embed: { color: "222222", description: `${warn} ${message.author} Please provide a valid url **${res}**` } })

                message.channel.send(`**<${res}>**`)
            })

        } else {

            shorten.custom(args[0], args[1], function(res) {
                if(res.startsWith('Error:')) return message.reply(` **${res}**`)

                message.channel.send(`**<${res}>**`)
            })

        }

    }
}