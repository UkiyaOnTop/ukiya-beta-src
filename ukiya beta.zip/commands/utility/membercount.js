const discord = require("discord.js");

module.exports = {
    config: {
        name: "membercount",
        description: "Show members in the servers",
        usage: "z!membercount",
        aliases: ["mc"]
    },
  run: async (client, message, args) => {
    
    let embed = new discord.MessageEmbed()
    .setAuthor(
    ``)
    .setDescription(`${message.guild.memberCount}`)
    .setColor("#222222")
    
    message.channel.send(embed)
  }
}