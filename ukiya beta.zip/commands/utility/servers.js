const { MessageEmbed } = require('discord.js');
const moment = require('moment');
const { mem, cpu, os } = require('node-os-utils');
const { stripIndent } = require('common-tags');

module.exports = {
    config: {
        name: "servers",
        aliases: ["guildcount", "guilds"],
        description:"",
        usage: ""
   },
  run: async (client, message, args) => {

    const clientStats = stripIndent`
      Servers   :: ${client.guilds.cache.size}
    `;
    
    const embed = new MessageEmbed()
      .setTitle('')
      .setDescription(`\`\`\`asciidoc\n${clientStats}\`\`\``)
  
      	
   .setColor("#222222")


  
    message.channel.send(embed);
    }
}
