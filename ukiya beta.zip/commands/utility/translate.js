const { Client, Message, MessageEmbed } = require('discord.js');
const translate = require('@iamtraction/google-translate');



module.exports = {
config: {
    name: "translate",
    description: "google translate",
    usage: ''
},
    /** 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run: async (client, message, args) => {

        try {
            const query = args.slice(1).join(" ");
            if (!query) return message.reply(`please give me something to translate`)
            const arg = args[0]

            const translated = await translate(query, { to: `${arg}` });
            const embed = new MessageEmbed()
                .setTitle("results")
                .addField("Your Query", `\`\`\`fix\n${query}\`\`\``)
                .addField('Selected Language', `\`\`\`fix\n${arg}\`\`\``)
                .addField('Result', `\`\`\`fix\n${translated.text}\`\`\``)
                .setColor("#222222")
            message.channel.send(embed)

        } catch (error) {
            return message.channel.send(`Your query is invalid`)
                .then(() => console.log(error));
        }

    }
}