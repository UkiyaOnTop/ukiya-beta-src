const Color = "#222222";
const Discord = require("discord.js");

module.exports = {
config: {
  name: "vote",
  aliases: ["upvote"]
},
  run: async (client, message, args) => {
    
   

    const Embed = new Discord.MessageEmbed()
    .setColor(Color)
    .setDescription(`[Vote 4 Ukiya](https://discordbotlist.com/bots/ukiya)`,true);

    return message.channel.send(Embed);
  }
}; 