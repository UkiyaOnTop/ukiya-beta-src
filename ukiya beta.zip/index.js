const { Client, MessageAttachment, Collection, MessageEmbed } = require('discord.js');
const { PREFIX, TOKEN, DBL_API_KEY } = require('./config');
const bot = new Client({ disableMentions: 'everyone' });
const DBL = require('dblapi.js');
const dbl = new DBL(DBL_API_KEY)
const fs = require("fs");
const db = require("quick.db");
const mongoose = require("mongoose")
const jimp = require('jimp');
const TikTokScraper = require('tiktok-scraper');
const config = require('./config.json');
const urlRegex = require('url-regex');
const axios = require('axios');
const nodeCleanup = require('node-cleanup');
const cron = require('node-cron');
const { execFile } = require('child_process');
const filesizeLimit = {
  default: 8 * 1024 * 1024 - 1000, // reserve 1KB for the message body
  tier2: 50 * 1024 * 1024 - 1000,
  tier3: 100 * 1024 * 1024 - 1000
};

let cooldown_users = new Set();
let database = fs.existsSync(config.DB_PATH) ? JSON.parse(fs.readFileSync(config.DB_PATH).toString()) : {};


bot.phone = new Collection();
bot.commands = new Collection();
bot.aliases = new Collection();

["aliases", "commands"].forEach(x => bot[x] = new Collection());
["console", "command", "event"].forEach(x => require(`./handler/${x}`)(bot));

bot.categories = fs.readdirSync("./commands/");

["command"].forEach(handler => {
  require(`./handler/${handler}`)(bot);
});
bot.on('ready', () => {
  setInterval(() => {
    dbl.postStats(bot.guilds.cache.size);
  }, 1800000);
});

mongoose.connect(process.env.MONGO, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  useFindAndModify: false,
});


/////////////////////////////////////////////////////////

/////////



bot.on('message', async message => {
  let prefix;
  try {
    let fetched = await db.fetch(`prefix_${message.guild.id}`);
    if (fetched == null) {
      prefix = PREFIX
    } else {
      prefix = fetched
    }
  } catch (e) {
    console.log(e)
  };
  try {
    if (message.mentions.has(bot.user) && !message.mentions.has(message.guild.id)) {
      return message.channel.send(`> my prefix for this guild is ${prefix}`)
    }
  } catch {
    return;
  };
});

// Auto-Role is here!

bot.on("guildMemberAdd", async (member) => {
  const roleData = require("./database/guildData/autorole")
  const data = await roleData.findOne({
    GuildID: member.guild.id,
  }).catch(err => console.log(err));

  if (data) {
    let role = data.Role;
    let arole = member.guild.roles.cache.get(role);
    if (role) {
      member.roles.add(arole)
    } else if (!role) {
      return;
    }
  } else if (!data) {
    return;
  }
});


//new server msg

bot.on('guildCreate', guild => {

  const channelId = '904391670953574466'; //put your bot log channel ID here

  const channel = bot.channels.cache.get(channelId);
  if (!channel) return;
  const embed = new MessageEmbed()
    .setTitle('**I Joined A Guild**')
    .setDescription(`> Guild Name: ${guild.name}\n> Members: ${guild.memberCount}`)
    .setColor('#222222')
    .setFooter(`I'm in ${bot.guilds.cache.size} Guilds Now!`);
  channel.send(embed);
});

// join msg

//
bot.on('guildCreate', guild => {
  const channel = guild.channels.cache.find(channel => channel.type === 'text' && channel.permissionsFor(guild.me).has('SEND_MESSAGES'))
  let embed = new MessageEmbed()
    .setColor('#222222')
    .setTitle(`hello there`)
    .setURL('https://discord.ly/ukiya')
    .setDescription(`> thank you for inviting me <:Bsmile:910003919491567688> \n\n> my prefix in this guild is __${PREFIX}__`);
  channel.send("<a:B777girls:910003924013047850>");
})

// leave msg

bot.on('guildDelete', guild => {
  const channelId = '904391670953574466';//add your channel ID
  const channel = bot.channels.cache.get(channelId); //This Gets That Channel

  if (!channel) return;  //If the channel is invalid it returns
  const embed = new MessageEmbed()
    .setTitle('**I Left A Guild**')
    .setDescription(`> Guild Name: ${guild.name}\n> Members: ${guild.memberCount}`)
    .setColor('#222222')
    .setFooter(`I'm in ${bot.guilds.cache.size} Guilds Now!`);
  channel.send(embed);
});

// snipe

bot.snipes = new Map()
bot.on('messageDelete', async function(message, guild) {
  if (message.partial) return
  if (message.channel.type === 'text') {
    if (message.author) {
      bot.snipes.set(message.channel.id, {
        content: message.content,
        author: message.author.tag,
        image: message.attachments.first() ? message.attachments.first().proxyURL : null
      })
    }
  }
})

// Welcome Here!
const welcomeData = require("./database/guildData/welcome")
const welcomemsg = require("./database/guildData/joinmsg")
bot.on(`guildMemberAdd`, async (member) => {

  const data = await welcomeData.findOne({
    GuildID: member.guild.id
  })

  if (data) {
    var channel = data.Welcome

    var data2 = await welcomemsg.findOne({
      GuildID: member.guild.id
    })
    if (data2) {
      var joinmessage = data2.JoinMsg;

      joinmessage = joinmessage.replace("{user.mention}", `${member}`)
      joinmessage = joinmessage.replace("{user.name}", `${member.user.tag}`)
      joinmessage = joinmessage.replace("{server}", `${member.guild.name}`)
      joinmessage = joinmessage.replace("{membercount}", `${member.guild.memberCount}`)

      let embed20 = new MessageEmbed()
        .setDescription(joinmessage)
        .setColor("#303135")
      member.guild.channels.cache.get(channel).send(joinmessage);
    }
  } else if (data2) {
    var channel = data.Welcome

    let embed200 = new MessageEmbed()
      .setTitle("Welcome")
      .setDescription(`${member}, Welcome to **${member.guild.name}**! We hope you like our Server! Enjoy Your Stay here!`)
      .setFooter(`We are now ${member.guild.memberCount} members`)
      .setColor("#303135")

    member.guild.channels.cache.get(channel).send(joinmessage)
  } else if (!data) {
    return;
  }
});

const byeData = require("./database/guildData/leavechannel")
const byemsg = require("./database/guildData/leavemessage")
bot.on(`guildMemberRemove`, async (member) => {
  const avatar = member.user.avatarURL;

  const data = await byeData.findOne({
    GuildID: member.guild.id
  })
  if (data) {

    const data2 = await byemsg.findOne({
      GuildID: member.guild.id
    })
    if (data2) {
      var leavemessage = data2.ByeMsg;

      leavemessage = leavemessage.replace("{user.mention}", `${member}`)
      leavemessage = leavemessage.replace("{user.name}", `${member.user.tag}`)
      leavemessage = leavemessage.replace("{server}", `${member.guild.name}`)
      leavemessage = leavemessage.replace("{membercount}", `${member.guild.memberCount}`)

      let embed = new MessageEmbed()
        .setDescription(leavemessage)
        .setColor("#222222");

      let channel = data.Bye

      member.guild.channels.cache.get(channel).send(leavemessage);

    } else if (!data2) {
      let embed2 = new MessageEmbed()
        .setTitle("Goodbye")
        .setThumbnail(member.user.avatarURL())
        .setDescription(`**${member.user.tag}** just left the server! We hope they return back soon!`)
        .setFooter(`We now have ${member.guild.memberCount} members!`)
        .setThumbnail(member.user.avatarURL())
        .setColor("#222222")

      let byechannel = data.Bye

      member.guild.channels.cache.get(byechannel).send(leavemessage);
    }
  } else if (!data) {
    return;
  }
});

//tiktok
bot.on('messageCreate', async msg => {
  if (!msg.content || msg.author.bot || cooldown_users.has(msg.author.id))
    return;
  let found_match = false;

  //convert to set to remove duplicates and then back to array to be able to slice (slicing so max 5 tiktoks per message)
  Array.from(new Set(msg.content.match(urlRegex()))).slice(0, config.MAX_TIKTOKS_PER_MESSAGE).forEach((url) => {
    if (/(www\.tiktok\.com)|(vm\.tiktok\.com)/.test(url)) {
      cooldown_users.add(msg.author.id);
      found_match = true;
      msg.channel.sendTyping().catch(console.error)

      TikTokScraper.getVideoMeta(url).then(tt_response =>
        axios.get(tt_response.collector[0].videoUrl, { responseType: 'arraybuffer', headers: tt_response.headers }).then(axios_response => {
          let too_large = is_too_large_attachment(msg.guild, axios_response);
          if (too_large && !config.BOOSTED_CHANNEL_ID)  // no channel set from which to borrow file size limits
            report_filesize_error(msg);
          else if (too_large)
            client.channels.fetch(config.BOOSTED_CHANNEL_ID).then(channel => {
              if (is_too_large_attachment(channel.guild, axios_response))
                report_filesize_error(msg);
              else
                channel.send({ files: [{ attachment: axios_response.data, name: `${tt_response.collector[0].id}.mp4` }] }).then(boosted_msg =>
                  msg.reply({ content: boosted_msg.attachments.first().attachment, allowedMentions: { repliedUser: false } }).then(update_database(msg, tt_response))
                    .catch(console.error)) // if the final reply failed
                  .catch(console.error); // if sending to the boosted channel failed
            }).catch(() => report_filesize_error(msg))
          else
            msg.reply({ files: [{ attachment: axios_response.data, name: `${tt_response.collector[0].id}.mp4` }], allowedMentions: { repliedUser: false } }).then(update_database(msg, tt_response))
              .catch(console.error) // if sending of the Discord message itself failed, just log error to console
        })
          .catch(err => report_error(msg, err)))  // if TikTokScraper.getVideoMeta() failed
        .catch(err => report_error(msg, err));  // if axios.get() failed
    }
    else if (config.EMBED_TWITTER_VIDEO && /\Wtwitter\.com\/.+?\/status\//.test(url)) {
      execFile('gallery-dl', ['-g', url], (error, stdout, stderr) => {
        if (error)
          return;
        if (/\.mp4/.test(stdout))
          msg.reply({ content: stdout, allowedMentions: { repliedUser: false } }).catch(console.error);
      });
    }
  });

  // very basic cooldown implementation to combat spam.
  // removes user id from set after cooldown_per_user ms.
  if (found_match)
    (async (id = msg.author.id) => {
      await new Promise(x => setTimeout(x, config.COOLDOWN_PER_USER));
      cooldown_users.delete(id);
    })();
})

function is_too_large_attachment(guild, stream) {
  let limit = 0;
  if (!guild)
    limit = filesizeLimit.default;
  else {
    switch (guild.premiumTier) {
      case 'NONE':
      case 'TIER_1':
        limit = filesizeLimit.default;
        break;
      case 'TIER_2':
        limit = filesizeLimit.tier2;
        break;
      case 'TIER_3':
        limit = filesizeLimit.tier3;
        break;
    }
  }
  return stream.data.length >= limit;
}

async function update_database(msg, tt_response) {
  if (!config.USE_DATABASE)
    return
  if (database.hasOwnProperty(msg.author.id)) {
    const userId = msg.author.id;
    const tt = tt_response.collector[0];
    if (database[userId]['downloads'].hasOwnProperty(tt.id))
      database[userId]['downloads'][tt.id]['count']++;
    else {
      let thumbnail = config.STORE_THUMBNAILS ? 'data:image/png;base64,' + Buffer.from((await axios.get(tt.imageUrl, { responseType: 'arraybuffer', headers: tt_response.headers }))
        .data, 'binary').toString('base64') : "";
      database[userId]['downloads'][tt.id] = {
        'count': 1,
        'description': tt.text,
        'userName': '@' + tt.authorMeta.name,
        'nickname': tt.authorMeta.nickName,
        'thumbnail': thumbnail
      };
    }
  }
  else {
    const userId = msg.author.id;
    const tt = tt_response.collector[0];
    let thumbnail = config.STORE_THUMBNAILS ? 'data:image/png;base64,' + Buffer.from((await axios.get(tt.imageUrl, { responseType: 'arraybuffer', headers: tt_response.headers }))
      .data, 'binary').toString('base64') : "";
    database[userId] = {
      'username': msg.author.tag,
      'firstDownload': Date.now(),
      'downloads': {
        [tt.id]: {
          'count': 1,
          'description': tt.text,
          'userName': '@' + tt.authorMeta.name,
          'nickname': tt.authorMeta.nickName,
          'thumbnail': thumbnail
        }
      }
    };
  }
}

//write database to file every hour
cron.schedule('0 * * * *', () =>
  fs.writeFileSync(config.DB_PATH, JSON.stringify(database)));

//write database to file on any exit reason
nodeCleanup((exitCode, signal) =>
  fs.writeFileSync(config.DB_PATH, JSON.stringify(database)));

function report_error(msg, error) {
  msg.reply({ content: `Error on trying to download this TikTok:\n\`${error}\``, allowedMentions: { repliedUser: false } }).catch(console.error);
}

function report_filesize_error(msg) {
  msg.reply({ content: 'This TikTok exceeds the file size limit Discord allows :*(', allowedMentions: { repliedUser: false } }).catch(console.error);
}


// presence

const presenceData = require('./database/guildData/pres');

bot.on('presenceUpdate', async (oldState, newState) => {
  if (!newState || !oldState) return;
  if (newState.user.bot || oldState.user.bot) return;
  const {
    guild
  } = newState;

  await presenceData.findOne({
    guild: guild.id
  }, async (err, data) => {
    if (!data) return;
    let des = data.content.descrip;
    let ro = data.content.role;

    //console.log(oldState, newState);
    //console.log(newState.activities[0], newState.activities[0].state);

    if (newState.activities[0].state.toLowerCase() == des.toLowerCase()) {
      const rol = guild.roles.cache.get(ro);
      const mem = guild.members.cache.get(newState.user.id);
      await mem.roles.add(rol);
    } else if (newState.activities[0].state.toLowerCase().includes(des.toLowerCase())) {
      const rol = guild.roles.cache.get(ro);
      const mem = guild.members.cache.get(newState.user.id);
      await mem.roles.add(rol);
    }
  })

});


//afk

bot.on("message", async message => {
  if (message.partial) return
  if (message.author.bot) return;

  if (message.author.bot) return;
  if (db.has(`afk-${message.author.id}+${message.guild.id}`)) {
    const info = db.get(`afk-${message.author.id}+${message.guild.id}`)
    await db.delete(`afk-${message.author.id}+${message.guild.id}`)
    message.channel.send({ embed: { color: "#222222", description: `:wave: ${message.author}: Welcome back, you're no longer **AFK**` } });
  }

  if (message.mentions.members.first()) {
    if (db.has(`afk-${message.mentions.members.first().id}+${message.guild.id}`)) {
      const embed = new Discord.MessageEmbed()
        .setColor("#222222")
        .setDescription(`${message.mentions.members.first()} is AFK: ` + db.get(`afk-${message.mentions.members.first().id}+${message.guild.id}`))
      message.channel.send(embed)
    } else return;
  } else;
});

bot.on('message', async message => {

  try {
    const hasText = Boolean(message.content);
    const hasImage = message.attachments.size !== 0;
    const hasEmbed = message.embeds.length !== 0;
    if (message.author.bot || (!hasText && !hasImage && !hasEmbed)) return;
    const origin = bot.phone.find(call => call.origin.id === message.channel.id);
    const recipient = bot.phone.find(call => call.recipient.id === message.channel.id);
    if (!origin && !recipient) return;
    const call = origin || recipient;
    if (!call.active) return;
    await call.send(origin ? call.recipient : call.origin, message, hasText, hasImage, hasEmbed);
  } catch {
    return;
  };
});

bot.on('guildMemberAdd', async member => {

  let wChan = db.fetch(`welcome_${member.guild.id}`)

  if (wChan == null) return;

  if (!wChan) return;

  let font64 = await jimp.loadFont(jimp.FONT_SANS_64_WHITE)
  let bfont64 = await jimp.loadFont(jimp.FONT_SANS_64_BLACK)
  let mask = await jimp.read('https://i.imgur.com/552kzaW.png')
  let welcome = await jimp.read('https://t.wallpaperweb.org/wallpaper/nature/1920x1080/greenroad1920x1080wallpaper3774.jpg')

  jimp.read(member.user.displayAvatarURL({ format: 'png' })).then(avatar => {
    avatar.resize(200, 200)
    mask.resize(200, 200)
    avatar.mask(mask)
    welcome.resize(1000, 300)

    welcome.print(font64, 265, 55, `Welcome ${member.user.username}`)
    welcome.print(bfont64, 265, 125, `To ${member.guild.name}`)
    welcome.print(font64, 265, 195, `There are now ${member.guild.memberCount} users`)
    welcome.composite(avatar, 40, 55).write('Welcome2.png')
    try {
      member.guild.channels.cache.get(wChan).send(``, { files: ["Welcome2.png"] })
    } catch (e) {

    }
  })
  var r = member.guild.roles.cache.find(r => r.name === 'Community');
  if (!r) return;
  member.roles.add(r)

});



const express = require('express');
const bodyParser = require('body-parser');
const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.get('/', function(request, response) {
  response.sendFile(__dirname + '/views/index.html');
});
app.listen(3000, () => console.log(`PROPER FUNCTIONING`));

//----------------------------- SISTEMA 24/7 -----------------------------//
const Discord = require('discord.js');
const client = new Discord.Client();


client.on("ready", () => {
  console.log(` ${bot.user.tag} ready`);
});

bot.login(process.env.TOKEN);
